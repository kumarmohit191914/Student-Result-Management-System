<?php
include('includes/config.php');
if (!empty($_POST["classid"])) {
  $cid = intval($_POST['classid']);
  if (!is_numeric($cid)) {

    echo htmlentities("invalid Class");
    exit;
  } else {
    $stmt = $dbh->prepare("SELECT StudentName,RollId FROM tblstudents WHERE ClassId= :id order by StudentName");
    $stmt->execute(array(':id' => $cid));
?>
    <option value="">Select Category </option>
    <?php
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    ?>
      <option value="<?php echo htmlentities($row['RollId']); ?>">
        <?php echo htmlentities($row['StudentName']); ?>&emsp;
        <?php echo htmlentities($row['RollId']); ?>
      </option>
    <?php
    }
  }
}
if (!empty($_POST["classid1"])) {
  $cid1 = intval($_POST['classid1']);
  if (!is_numeric($cid1)) {

    echo htmlentities("invalid Class");
    exit;
  } else {
    $status = 0;
    $stmt = $dbh->prepare("SELECT tblsubjects.SubjectName,tblsubjects.ClassId,tblsubjects.SubjectCode FROM tblsubjectcombination join  tblsubjects on  tblsubjects.SubjectCode=tblsubjectcombination.SubjectId and tblsubjects.ClassId=tblsubjectcombination.ClassId WHERE tblsubjectcombination.ClassId=:cid and tblsubjectcombination.status!=:stts order by tblsubjects.SubjectCode");
    $stmt->execute(array(':cid' => $cid1, ':stts' => $status));

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) { ?>
      <p>
        <?php echo htmlentities($row['SubjectName']); ?>
        <?php echo htmlentities($row['SubjectCode']); ?><input type="text" name="marks[]" value="" class="form-control" required="" placeholder="Enter marks" autocomplete="off">
      </p>

<?php  }
  }
}


?>

<?php

if (!empty($_POST["studclass"])) {
  $id = $_POST['studclass'];
  $dta = explode("$", $id);
  $id = $dta[0];
  $id1 = $dta[1];
  $query = $dbh->prepare("SELECT StudentId,ClassId FROM tblresult WHERE StudentId=:id1 and ClassId=:id");

  $query->bindParam(':id1', $id1, PDO::PARAM_STR);
  $query->bindParam(':id', $id, PDO::PARAM_STR);

  $query->execute();
  $results = $query->fetchAll(PDO::FETCH_OBJ);
  $cnt = 1;
  if ($query->rowCount() > 0) { ?>
    <p>
      <?php
      echo "<span style='color:red'> Result Already Declare .</span>";
      echo "<script>$('#submit').prop('disabled', true);</script>";
      ?>
    </p>
<?php }
} ?>