<?php
$dbuser="root";
$dbpass="123";
$host="localhost";
$dbname = "srms1";
$mysqli = new mysqli($host, $dbuser, $dbpass, $dbname);

?>